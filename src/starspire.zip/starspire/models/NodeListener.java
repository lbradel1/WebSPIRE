package starspire.models;

///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package forcespire.models;
//
///**
// * This interface describes the requirements for the nodes to listen.
// *
// * @author Pat
// */
//public interface NodeListener {
//    /*
//     * Node Events
//     */
//
//    /**
//     * This even is triggered when a node is opened.
//     * @param n Node opened
//     */
//    public void nodeOpened(Node n);
//
//    /**
//     * This event is triggered when a node is closed.
//     * @param n Node closed
//     */
//    public void nodeClosed(Node n);
//
//    /**
//     * This event is triggered when a node is moved.
//     * @param n Node moved
//     */
//    public void nodeMoved(Node n);
//    
//    /**
//     * This event is triggered when a node is modified.
//     * @param n Node modified
//     */
//    public void nodeModified(Node n);
//
//    
//}
